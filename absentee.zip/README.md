# NITAFAN — Absentee Property Owner Landing Page

A static, dependency-free landing page for Glennis Nitafan's absentee-owner
property service. Plain HTML/CSS/JS — no build step, no framework, no npm
install required to run or deploy it.

## Files

```
index.html    Page markup and copy
styles.css    All styling (mobile-first, one stylesheet)
script.js     Contact form handling (opens a pre-filled email)
vercel.json   Vercel config (clean URLs)
package.json  Optional — only used for the local preview script
```

## Before you deploy

Open `script.js` and change this line to the email address that should
receive inquiries:

```js
var CONTACT_EMAIL = 'hello@nitafan.com';
```

The form currently opens the visitor's email app with a pre-filled message
(no backend needed). If you'd rather collect submissions directly — e.g.
into Google Sheets, Airtable, or a form service — swap the `fetch`/`mailto`
logic in `script.js` for that provider's endpoint.

## Preview locally

No install needed if you have Python:

```bash
python3 -m http.server 8000
```

Or, if you have Node:

```bash
npx serve .
```

Then open `http://localhost:8000` (or whatever port is shown).

## Deploy to GitHub + Vercel

1. Create a new GitHub repository and push this folder to it:

   ```bash
   git init
   git add .
   git commit -m "Initial NITAFAN landing page"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

2. Go to [vercel.com/new](https://vercel.com/new) and import that GitHub
   repository.

3. Vercel will detect it as a static site automatically — no framework
   preset, no build command, no output directory needed. Leave those
   fields as-is and click **Deploy**.

4. Once deployed, add your custom domain (e.g. `nitafan.com`) under
   **Project Settings → Domains**.

That's it — there's nothing to build, so there's nothing that can break at
build time.

## Customizing

- **Colors / fonts**: all defined as CSS variables at the top of
  `styles.css` under `:root`.
- **Copy**: all section text lives directly in `index.html`.
- **CTA email**: `CONTACT_EMAIL` in `script.js`.
