// NITAFAN landing page — lightweight interactions, no dependencies.

(function () {
  var form = document.getElementById('contact-form');
  var status = document.getElementById('form-status');

  if (!form) return;

  // Replace with the address that should receive inquiries.
  var CONTACT_EMAIL = 'hello@nitafan.com';

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var name = form.name.value.trim();
    var email = form.email.value.trim();
    var location = form.location.value.trim();
    var message = form.message.value.trim();

    if (!name || !email || !message) {
      status.textContent = 'Please fill in your name, email, and a short message.';
      return;
    }

    var subject = encodeURIComponent('Property inquiry from ' + name);
    var bodyLines = [
      'Name: ' + name,
      'Email: ' + email,
      'Based in: ' + (location || 'Not specified'),
      '',
      message
    ];
    var body = encodeURIComponent(bodyLines.join('\n'));

    window.location.href = 'mailto:' + CONTACT_EMAIL + '?subject=' + subject + '&body=' + body;
    status.textContent = 'Opening your email app to send this to Glennis.';
  });
})();
